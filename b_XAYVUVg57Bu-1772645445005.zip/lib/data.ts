// ─── Types ───────────────────────────────────────────────

export interface Event {
  id: string
  name: string
  date: string
  location: string
  status: "upcoming" | "active" | "completed"
  participants: number
  maxParticipants: number
  category: string
}

export interface Participant {
  id: string
  name: string
  email: string
  team: string
  events: number
  score: number
  rank: number
  avatar: string
  status: "registered" | "checked-in" | "competing" | "finished"
}

export interface ScoreEntry {
  id: string
  participantName: string
  eventName: string
  score: number
  maxScore: number
  judge: string
  timestamp: string
  category: string
}

export interface LeaderboardEntry {
  rank: number
  name: string
  team: string
  totalScore: number
  eventsCompleted: number
  avatar: string
  trend: "up" | "down" | "stable"
  previousRank: number
}

// ─── Mock Data ───────────────────────────────────────────

export const events: Event[] = [
  {
    id: "evt-001",
    name: "Sprint Challenge",
    date: "2026-03-15",
    location: "Main Arena",
    status: "active",
    participants: 42,
    maxParticipants: 50,
    category: "Athletics",
  },
  {
    id: "evt-002",
    name: "Technical Quiz",
    date: "2026-03-16",
    location: "Hall B",
    status: "upcoming",
    participants: 28,
    maxParticipants: 60,
    category: "Academic",
  },
  {
    id: "evt-003",
    name: "Relay Race",
    date: "2026-03-14",
    location: "Track Field",
    status: "completed",
    participants: 36,
    maxParticipants: 36,
    category: "Athletics",
  },
  {
    id: "evt-004",
    name: "Debate Championship",
    date: "2026-03-17",
    location: "Auditorium",
    status: "upcoming",
    participants: 16,
    maxParticipants: 32,
    category: "Academic",
  },
  {
    id: "evt-005",
    name: "Obstacle Course",
    date: "2026-03-15",
    location: "Outdoor Field",
    status: "active",
    participants: 24,
    maxParticipants: 30,
    category: "Athletics",
  },
  {
    id: "evt-006",
    name: "Art Exhibition",
    date: "2026-03-18",
    location: "Gallery Wing",
    status: "upcoming",
    participants: 18,
    maxParticipants: 40,
    category: "Creative",
  },
  {
    id: "evt-007",
    name: "Coding Marathon",
    date: "2026-03-14",
    location: "Lab 3",
    status: "completed",
    participants: 50,
    maxParticipants: 50,
    category: "Technical",
  },
  {
    id: "evt-008",
    name: "Swimming Finals",
    date: "2026-03-19",
    location: "Aquatic Center",
    status: "upcoming",
    participants: 20,
    maxParticipants: 24,
    category: "Athletics",
  },
]

export const participants: Participant[] = [
  { id: "p-001", name: "Alex Rivera", email: "alex.r@example.com", team: "Phoenix", events: 4, score: 892, rank: 1, avatar: "AR", status: "competing" },
  { id: "p-002", name: "Jordan Kim", email: "jordan.k@example.com", team: "Thunder", events: 3, score: 845, rank: 2, avatar: "JK", status: "competing" },
  { id: "p-003", name: "Sam Patel", email: "sam.p@example.com", team: "Phoenix", events: 5, score: 823, rank: 3, avatar: "SP", status: "checked-in" },
  { id: "p-004", name: "Casey Morgan", email: "casey.m@example.com", team: "Blaze", events: 3, score: 798, rank: 4, avatar: "CM", status: "competing" },
  { id: "p-005", name: "Taylor Brooks", email: "taylor.b@example.com", team: "Thunder", events: 4, score: 776, rank: 5, avatar: "TB", status: "finished" },
  { id: "p-006", name: "Morgan Lee", email: "morgan.l@example.com", team: "Blaze", events: 2, score: 754, rank: 6, avatar: "ML", status: "registered" },
  { id: "p-007", name: "Riley Chen", email: "riley.c@example.com", team: "Storm", events: 4, score: 731, rank: 7, avatar: "RC", status: "competing" },
  { id: "p-008", name: "Avery Nguyen", email: "avery.n@example.com", team: "Storm", events: 3, score: 718, rank: 8, avatar: "AN", status: "checked-in" },
  { id: "p-009", name: "Quinn Davis", email: "quinn.d@example.com", team: "Phoenix", events: 5, score: 695, rank: 9, avatar: "QD", status: "finished" },
  { id: "p-010", name: "Drew Santos", email: "drew.s@example.com", team: "Thunder", events: 2, score: 672, rank: 10, avatar: "DS", status: "registered" },
  { id: "p-011", name: "Jamie Walsh", email: "jamie.w@example.com", team: "Blaze", events: 4, score: 658, rank: 11, avatar: "JW", status: "competing" },
  { id: "p-012", name: "Reese Harper", email: "reese.h@example.com", team: "Storm", events: 3, score: 641, rank: 12, avatar: "RH", status: "checked-in" },
]

export const scores: ScoreEntry[] = [
  { id: "s-001", participantName: "Alex Rivera", eventName: "Sprint Challenge", score: 95, maxScore: 100, judge: "Coach Williams", timestamp: "2026-03-15 10:30", category: "Athletics" },
  { id: "s-002", participantName: "Jordan Kim", eventName: "Sprint Challenge", score: 91, maxScore: 100, judge: "Coach Williams", timestamp: "2026-03-15 10:32", category: "Athletics" },
  { id: "s-003", participantName: "Sam Patel", eventName: "Technical Quiz", score: 88, maxScore: 100, judge: "Prof. Adams", timestamp: "2026-03-16 14:00", category: "Academic" },
  { id: "s-004", participantName: "Casey Morgan", eventName: "Relay Race", score: 92, maxScore: 100, judge: "Coach Davis", timestamp: "2026-03-14 11:15", category: "Athletics" },
  { id: "s-005", participantName: "Taylor Brooks", eventName: "Coding Marathon", score: 87, maxScore: 100, judge: "Dr. Singh", timestamp: "2026-03-14 18:00", category: "Technical" },
  { id: "s-006", participantName: "Morgan Lee", eventName: "Obstacle Course", score: 78, maxScore: 100, judge: "Coach Williams", timestamp: "2026-03-15 15:45", category: "Athletics" },
  { id: "s-007", participantName: "Riley Chen", eventName: "Sprint Challenge", score: 85, maxScore: 100, judge: "Coach Williams", timestamp: "2026-03-15 10:35", category: "Athletics" },
  { id: "s-008", participantName: "Avery Nguyen", eventName: "Technical Quiz", score: 93, maxScore: 100, judge: "Prof. Adams", timestamp: "2026-03-16 14:05", category: "Academic" },
  { id: "s-009", participantName: "Alex Rivera", eventName: "Relay Race", score: 97, maxScore: 100, judge: "Coach Davis", timestamp: "2026-03-14 11:20", category: "Athletics" },
  { id: "s-010", participantName: "Jordan Kim", eventName: "Coding Marathon", score: 90, maxScore: 100, judge: "Dr. Singh", timestamp: "2026-03-14 18:05", category: "Technical" },
]

export const leaderboard: LeaderboardEntry[] = [
  { rank: 1, name: "Alex Rivera", team: "Phoenix", totalScore: 892, eventsCompleted: 4, avatar: "AR", trend: "up", previousRank: 2 },
  { rank: 2, name: "Jordan Kim", team: "Thunder", totalScore: 845, eventsCompleted: 3, avatar: "JK", trend: "up", previousRank: 3 },
  { rank: 3, name: "Sam Patel", team: "Phoenix", totalScore: 823, eventsCompleted: 5, avatar: "SP", trend: "down", previousRank: 1 },
  { rank: 4, name: "Casey Morgan", team: "Blaze", totalScore: 798, eventsCompleted: 3, avatar: "CM", trend: "stable", previousRank: 4 },
  { rank: 5, name: "Taylor Brooks", team: "Thunder", totalScore: 776, eventsCompleted: 4, avatar: "TB", trend: "up", previousRank: 7 },
  { rank: 6, name: "Morgan Lee", team: "Blaze", totalScore: 754, eventsCompleted: 2, avatar: "ML", trend: "down", previousRank: 5 },
  { rank: 7, name: "Riley Chen", team: "Storm", totalScore: 731, eventsCompleted: 4, avatar: "RC", trend: "up", previousRank: 9 },
  { rank: 8, name: "Avery Nguyen", team: "Storm", totalScore: 718, eventsCompleted: 3, avatar: "AN", trend: "down", previousRank: 6 },
  { rank: 9, name: "Quinn Davis", team: "Phoenix", totalScore: 695, eventsCompleted: 5, avatar: "QD", trend: "stable", previousRank: 9 },
  { rank: 10, name: "Drew Santos", team: "Thunder", totalScore: 672, eventsCompleted: 2, avatar: "DS", trend: "down", previousRank: 8 },
  { rank: 11, name: "Jamie Walsh", team: "Blaze", totalScore: 658, eventsCompleted: 4, avatar: "JW", trend: "up", previousRank: 12 },
  { rank: 12, name: "Reese Harper", team: "Storm", totalScore: 641, eventsCompleted: 3, avatar: "RH", trend: "down", previousRank: 10 },
]

export const dashboardStats = {
  totalEvents: 8,
  activeEvents: 2,
  totalParticipants: 234,
  averageScore: 78.5,
  completionRate: 85,
  topTeam: "Phoenix",
}

export const recentActivity = [
  { action: "Score submitted", detail: "Alex Rivera scored 95 in Sprint Challenge", time: "2 min ago" },
  { action: "Participant registered", detail: "Drew Santos joined Technical Quiz", time: "15 min ago" },
  { action: "Event completed", detail: "Relay Race finished with 36 participants", time: "1 hr ago" },
  { action: "Score submitted", detail: "Jordan Kim scored 91 in Sprint Challenge", time: "1 hr ago" },
  { action: "Event started", detail: "Sprint Challenge is now active", time: "2 hrs ago" },
  { action: "Participant registered", detail: "Morgan Lee joined Obstacle Course", time: "3 hrs ago" },
]

export const teamScores = [
  { team: "Phoenix", score: 2410, members: 3 },
  { team: "Thunder", score: 2293, members: 3 },
  { team: "Blaze", score: 2210, members: 3 },
  { team: "Storm", score: 2090, members: 3 },
]

export const scoreDistribution = [
  { range: "90-100", count: 4 },
  { range: "80-89", count: 3 },
  { range: "70-79", count: 2 },
  { range: "60-69", count: 1 },
]
