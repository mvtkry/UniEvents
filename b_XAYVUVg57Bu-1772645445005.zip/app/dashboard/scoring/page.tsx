"use client"

import { useState } from "react"
import { Search, Clock, CheckCircle2 } from "lucide-react"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { StatCard } from "@/components/dashboard/stat-card"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Progress } from "@/components/ui/progress"
import { scores, scoreDistribution } from "@/lib/data"
import { Target, TrendingUp } from "lucide-react"

export default function ScoringPage() {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredScores = scores.filter(
    (s) =>
      s.participantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.eventName.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const avgScore = Math.round(
    scores.reduce((a, b) => a + b.score, 0) / scores.length
  )
  const highestScore = Math.max(...scores.map((s) => s.score))
  const totalEntries = scores.length

  return (
    <DashboardShell
      title="Scoring"
      description="View scores and judge entries"
    >
      <div className="flex flex-col gap-6">
        {/* Stats */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard
            title="Total Entries"
            value={totalEntries}
            icon={Target}
            subtitle="Score submissions"
          />
          <StatCard
            title="Average Score"
            value={`${avgScore}%`}
            icon={TrendingUp}
            subtitle="Across all events"
          />
          <StatCard
            title="Highest Score"
            value={`${highestScore}%`}
            icon={CheckCircle2}
            subtitle="Best performance"
            trend={{ value: "Alex Rivera", positive: true }}
          />
          <StatCard
            title="Judges Active"
            value="4"
            icon={Clock}
            subtitle="Currently scoring"
          />
        </div>

        {/* Score Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Score Distribution</CardTitle>
            <CardDescription>
              How scores are distributed across ranges
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              {scoreDistribution.map((dist) => (
                <div
                  key={dist.range}
                  className="flex flex-col items-center gap-2 rounded-lg border border-border bg-secondary/30 p-4"
                >
                  <span className="text-sm font-medium text-muted-foreground">
                    {dist.range}
                  </span>
                  <span className="text-3xl font-bold text-foreground">
                    {dist.count}
                  </span>
                  <Progress
                    value={(dist.count / totalEntries) * 100}
                    className="h-1.5 w-full"
                  />
                  <span className="text-xs text-muted-foreground">
                    {Math.round((dist.count / totalEntries) * 100)}% of total
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Search */}
        <div className="flex items-center justify-between">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search by participant or event..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-9 w-full rounded-lg border border-input bg-card pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring sm:w-80"
            />
          </div>
        </div>

        {/* Scores Table */}
        <Card>
          <CardHeader>
            <CardTitle>Score Entries</CardTitle>
            <CardDescription>
              {filteredScores.length} entr{filteredScores.length !== 1 ? "ies" : "y"}{" "}
              found
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Participant</TableHead>
                  <TableHead>Event</TableHead>
                  <TableHead className="hidden sm:table-cell">Category</TableHead>
                  <TableHead>Score</TableHead>
                  <TableHead className="hidden md:table-cell">Judge</TableHead>
                  <TableHead className="hidden lg:table-cell">
                    Timestamp
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredScores.map((entry) => {
                  const percentage = Math.round(
                    (entry.score / entry.maxScore) * 100
                  )
                  return (
                    <TableRow key={entry.id}>
                      <TableCell>
                        <span className="text-sm font-medium text-foreground">
                          {entry.participantName}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className="text-sm text-foreground">
                          {entry.eventName}
                        </span>
                      </TableCell>
                      <TableCell className="hidden sm:table-cell">
                        <span className="rounded-md bg-secondary px-2 py-1 text-xs font-medium text-secondary-foreground">
                          {entry.category}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-semibold text-foreground">
                            {entry.score}/{entry.maxScore}
                          </span>
                          <div className="hidden w-16 sm:block">
                            <Progress value={percentage} className="h-1.5" />
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        <span className="text-sm text-muted-foreground">
                          {entry.judge}
                        </span>
                      </TableCell>
                      <TableCell className="hidden lg:table-cell">
                        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                          <Clock className="size-3" />
                          {entry.timestamp}
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  )
}
