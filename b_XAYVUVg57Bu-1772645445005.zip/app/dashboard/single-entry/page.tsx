"use client"

import { useState } from "react"
import {
  CheckCircle2,
  AlertCircle,
} from "lucide-react"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card"
import { events, participants } from "@/lib/data"

interface FormData {
  participantId: string
  eventId: string
  score: string
  maxScore: string
  judge: string
  notes: string
}

export default function SingleEntryPage() {
  const [formData, setFormData] = useState<FormData>({
    participantId: "",
    eventId: "",
    score: "",
    maxScore: "100",
    judge: "",
    notes: "",
  })
  const [submitted, setSubmitted] = useState(false)
  const [error, setError] = useState("")

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement
    >
  ) => {
    setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }))
    setError("")
    setSubmitted(false)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (
      !formData.participantId ||
      !formData.eventId ||
      !formData.score ||
      !formData.judge
    ) {
      setError("Please fill in all required fields.")
      return
    }
    const score = Number(formData.score)
    const maxScore = Number(formData.maxScore)
    if (isNaN(score) || score < 0 || score > maxScore) {
      setError(`Score must be between 0 and ${maxScore}.`)
      return
    }
    setSubmitted(true)
    setFormData({
      participantId: "",
      eventId: "",
      score: "",
      maxScore: "100",
      judge: "",
      notes: "",
    })
  }

  const selectedParticipant = participants.find(
    (p) => p.id === formData.participantId
  )
  const selectedEvent = events.find((e) => e.id === formData.eventId)

  return (
    <DashboardShell
      title="Single Entry"
      description="Submit a new score entry for a participant"
    >
      <div className="mx-auto max-w-2xl">
        <div className="flex flex-col gap-6">
          {/* Success Message */}
          {submitted && (
            <div className="flex items-center gap-3 rounded-lg border border-success/30 bg-success/10 p-4">
              <CheckCircle2 className="size-5 text-success shrink-0" />
              <div>
                <p className="text-sm font-medium text-foreground">
                  Score submitted successfully
                </p>
                <p className="text-xs text-muted-foreground">
                  The entry has been recorded and the leaderboard has been
                  updated.
                </p>
              </div>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="flex items-center gap-3 rounded-lg border border-destructive/30 bg-destructive/10 p-4">
              <AlertCircle className="size-5 text-destructive shrink-0" />
              <p className="text-sm text-foreground">{error}</p>
            </div>
          )}

          {/* Form */}
          <Card>
            <CardHeader>
              <CardTitle>New Score Entry</CardTitle>
              <CardDescription>
                Fill in the details below to record a score.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                {/* Participant */}
                <div className="flex flex-col gap-1.5">
                  <label
                    htmlFor="participantId"
                    className="text-sm font-medium text-foreground"
                  >
                    Participant <span className="text-destructive">*</span>
                  </label>
                  <select
                    id="participantId"
                    name="participantId"
                    value={formData.participantId}
                    onChange={handleChange}
                    className="h-10 rounded-lg border border-input bg-card px-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option value="">Select a participant</option>
                    {participants.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.team})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Event */}
                <div className="flex flex-col gap-1.5">
                  <label
                    htmlFor="eventId"
                    className="text-sm font-medium text-foreground"
                  >
                    Event <span className="text-destructive">*</span>
                  </label>
                  <select
                    id="eventId"
                    name="eventId"
                    value={formData.eventId}
                    onChange={handleChange}
                    className="h-10 rounded-lg border border-input bg-card px-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option value="">Select an event</option>
                    {events.map((e) => (
                      <option key={e.id} value={e.id}>
                        {e.name} - {e.category}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Score */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label
                      htmlFor="score"
                      className="text-sm font-medium text-foreground"
                    >
                      Score <span className="text-destructive">*</span>
                    </label>
                    <input
                      type="number"
                      id="score"
                      name="score"
                      value={formData.score}
                      onChange={handleChange}
                      min={0}
                      max={Number(formData.maxScore)}
                      placeholder="0"
                      className="h-10 rounded-lg border border-input bg-card px-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label
                      htmlFor="maxScore"
                      className="text-sm font-medium text-foreground"
                    >
                      Max Score
                    </label>
                    <input
                      type="number"
                      id="maxScore"
                      name="maxScore"
                      value={formData.maxScore}
                      onChange={handleChange}
                      min={1}
                      className="h-10 rounded-lg border border-input bg-card px-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                </div>

                {/* Judge */}
                <div className="flex flex-col gap-1.5">
                  <label
                    htmlFor="judge"
                    className="text-sm font-medium text-foreground"
                  >
                    Judge Name <span className="text-destructive">*</span>
                  </label>
                  <input
                    type="text"
                    id="judge"
                    name="judge"
                    value={formData.judge}
                    onChange={handleChange}
                    placeholder="Enter judge name"
                    className="h-10 rounded-lg border border-input bg-card px-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>

                {/* Notes */}
                <div className="flex flex-col gap-1.5">
                  <label
                    htmlFor="notes"
                    className="text-sm font-medium text-foreground"
                  >
                    Notes <span className="text-xs text-muted-foreground">(optional)</span>
                  </label>
                  <textarea
                    id="notes"
                    name="notes"
                    value={formData.notes}
                    onChange={handleChange}
                    rows={3}
                    placeholder="Additional notes about this score..."
                    className="rounded-lg border border-input bg-card px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none"
                  />
                </div>

                {/* Preview */}
                {(selectedParticipant || selectedEvent) && (
                  <div className="rounded-lg border border-border bg-secondary/30 p-4">
                    <p className="mb-2 text-xs font-medium text-muted-foreground uppercase tracking-wider">
                      Entry Preview
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      {selectedParticipant && (
                        <>
                          <span className="text-muted-foreground">
                            Participant:
                          </span>
                          <span className="font-medium text-foreground">
                            {selectedParticipant.name}
                          </span>
                        </>
                      )}
                      {selectedEvent && (
                        <>
                          <span className="text-muted-foreground">Event:</span>
                          <span className="font-medium text-foreground">
                            {selectedEvent.name}
                          </span>
                        </>
                      )}
                      {formData.score && (
                        <>
                          <span className="text-muted-foreground">Score:</span>
                          <span className="font-semibold text-foreground">
                            {formData.score}/{formData.maxScore}
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                )}

                {/* Submit */}
                <button
                  type="submit"
                  className="h-10 rounded-lg bg-primary px-6 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
                >
                  Submit Score Entry
                </button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardShell>
  )
}
