import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "EventHub Dashboard",
  description: "Manage events, participants, scoring, and leaderboards",
}

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
