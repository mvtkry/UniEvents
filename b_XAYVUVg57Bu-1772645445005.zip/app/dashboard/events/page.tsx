"use client"

import { useState } from "react"
import {
  Calendar,
  MapPin,
  Users as UsersIcon,
  Search,
  Filter,
} from "lucide-react"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { StatusBadge } from "@/components/dashboard/status-badge"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Progress } from "@/components/ui/progress"
import { events } from "@/lib/data"

const categories = ["All", "Athletics", "Academic", "Technical", "Creative"]

export default function EventsPage() {
  const [activeCategory, setActiveCategory] = useState("All")
  const [searchQuery, setSearchQuery] = useState("")

  const filtered = events.filter((event) => {
    const matchesCategory =
      activeCategory === "All" || event.category === activeCategory
    const matchesSearch = event.name
      .toLowerCase()
      .includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  return (
    <DashboardShell title="Events" description="Manage all competition events">
      <div className="flex flex-col gap-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <Card className="gap-0 py-4">
            <CardContent className="flex flex-col items-center gap-1">
              <span className="text-2xl font-bold text-foreground">{events.length}</span>
              <span className="text-xs text-muted-foreground">Total Events</span>
            </CardContent>
          </Card>
          <Card className="gap-0 py-4">
            <CardContent className="flex flex-col items-center gap-1">
              <span className="text-2xl font-bold text-success">
                {events.filter((e) => e.status === "active").length}
              </span>
              <span className="text-xs text-muted-foreground">Active Now</span>
            </CardContent>
          </Card>
          <Card className="gap-0 py-4">
            <CardContent className="flex flex-col items-center gap-1">
              <span className="text-2xl font-bold text-primary">
                {events.filter((e) => e.status === "upcoming").length}
              </span>
              <span className="text-xs text-muted-foreground">Upcoming</span>
            </CardContent>
          </Card>
          <Card className="gap-0 py-4">
            <CardContent className="flex flex-col items-center gap-1">
              <span className="text-2xl font-bold text-muted-foreground">
                {events.filter((e) => e.status === "completed").length}
              </span>
              <span className="text-xs text-muted-foreground">Completed</span>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2 overflow-x-auto">
            <Filter className="size-4 text-muted-foreground shrink-0" />
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`shrink-0 rounded-lg px-3 py-1.5 text-sm font-medium transition-colors ${
                  activeCategory === cat
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search events..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-9 w-full rounded-lg border border-input bg-card pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring sm:w-64"
            />
          </div>
        </div>

        {/* Events Table */}
        <Card>
          <CardHeader>
            <CardTitle>All Events</CardTitle>
            <CardDescription>
              {filtered.length} event{filtered.length !== 1 ? "s" : ""} found
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Event</TableHead>
                  <TableHead className="hidden sm:table-cell">Date</TableHead>
                  <TableHead className="hidden md:table-cell">Location</TableHead>
                  <TableHead className="hidden lg:table-cell">Category</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="hidden sm:table-cell">Capacity</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((event) => (
                  <TableRow key={event.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="flex size-9 items-center justify-center rounded-lg bg-primary/10">
                          <Calendar className="size-4 text-primary" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-foreground">
                            {event.name}
                          </p>
                          <p className="text-xs text-muted-foreground sm:hidden">
                            {event.date}
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="hidden sm:table-cell">
                      <span className="text-sm text-foreground">{event.date}</span>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                        <MapPin className="size-3.5" />
                        {event.location}
                      </div>
                    </TableCell>
                    <TableCell className="hidden lg:table-cell">
                      <span className="rounded-md bg-secondary px-2 py-1 text-xs font-medium text-secondary-foreground">
                        {event.category}
                      </span>
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={event.status} />
                    </TableCell>
                    <TableCell className="hidden sm:table-cell">
                      <div className="flex flex-col gap-1.5">
                        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                          <UsersIcon className="size-3" />
                          {event.participants}/{event.maxParticipants}
                        </div>
                        <Progress
                          value={
                            (event.participants / event.maxParticipants) * 100
                          }
                          className="h-1.5"
                        />
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  )
}
