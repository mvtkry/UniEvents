"use client"

import {
  Calendar,
  Users,
  Target,
  Trophy,
  TrendingUp,
  Clock,
  ArrowUpRight,
} from "lucide-react"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { StatCard } from "@/components/dashboard/stat-card"
import { StatusBadge } from "@/components/dashboard/status-badge"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import {
  dashboardStats,
  recentActivity,
  events,
  leaderboard,
  teamScores,
} from "@/lib/data"

export default function DashboardPage() {
  const upcomingEvents = events
    .filter((e) => e.status === "upcoming" || e.status === "active")
    .slice(0, 4)

  const topPerformers = leaderboard.slice(0, 5)

  return (
    <DashboardShell
      title="Overview"
      description="Welcome back. Here's what's happening."
    >
      <div className="flex flex-col gap-6">
        {/* Stat Cards */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard
            title="Total Events"
            value={dashboardStats.totalEvents}
            subtitle="Across all categories"
            icon={Calendar}
            trend={{ value: "+2 this week", positive: true }}
          />
          <StatCard
            title="Active Events"
            value={dashboardStats.activeEvents}
            subtitle="Currently running"
            icon={Target}
            trend={{ value: "Live now", positive: true }}
          />
          <StatCard
            title="Participants"
            value={dashboardStats.totalParticipants}
            subtitle="Total registered"
            icon={Users}
            trend={{ value: "+18 today", positive: true }}
          />
          <StatCard
            title="Avg. Score"
            value={`${dashboardStats.averageScore}%`}
            subtitle="Overall performance"
            icon={TrendingUp}
            trend={{ value: "+2.3% from last week", positive: true }}
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Upcoming Events */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Upcoming Events</CardTitle>
              <CardDescription>Events happening soon</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col gap-3">
                {upcomingEvents.map((event) => (
                  <div
                    key={event.id}
                    className="flex items-center justify-between rounded-lg border border-border bg-secondary/30 p-3"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex size-10 items-center justify-center rounded-lg bg-primary/10">
                        <Calendar className="size-4 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-foreground">
                          {event.name}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {event.location} &middot; {event.date}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <StatusBadge status={event.status} />
                      <span className="hidden text-xs text-muted-foreground sm:inline-block">
                        {event.participants}/{event.maxParticipants}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Latest updates</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col gap-4">
                {recentActivity.map((activity, i) => (
                  <div key={i} className="flex gap-3">
                    <div className="relative mt-1">
                      <div className="flex size-2 items-center justify-center rounded-full bg-primary" />
                      {i < recentActivity.length - 1 && (
                        <div className="absolute left-1/2 top-3 h-full w-px -translate-x-1/2 bg-border" />
                      )}
                    </div>
                    <div className="flex-1 pb-4">
                      <p className="text-sm font-medium text-foreground">
                        {activity.action}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {activity.detail}
                      </p>
                      <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                        <Clock className="size-3" />
                        {activity.time}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Bottom Section */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          {/* Top Performers */}
          <Card>
            <CardHeader>
              <CardTitle>Top Performers</CardTitle>
              <CardDescription>Leading the competition</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col gap-3">
                {topPerformers.map((entry) => (
                  <div
                    key={entry.rank}
                    className="flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <span className="flex size-6 items-center justify-center rounded-md bg-secondary text-xs font-bold text-secondary-foreground">
                        {entry.rank}
                      </span>
                      <Avatar className="size-8">
                        <AvatarFallback className="bg-primary/10 text-primary text-xs">
                          {entry.avatar}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="text-sm font-medium text-foreground">
                          {entry.name}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {entry.team}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-foreground">
                        {entry.totalScore}
                      </span>
                      {entry.trend === "up" && (
                        <ArrowUpRight className="size-3.5 text-success" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Team Scores */}
          <Card>
            <CardHeader>
              <CardTitle>Team Standings</CardTitle>
              <CardDescription>
                Combined team scores
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col gap-4">
                {teamScores.map((team, i) => (
                  <div key={team.team} className="flex flex-col gap-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Trophy
                          className={`size-4 ${
                            i === 0
                              ? "text-chart-3"
                              : "text-muted-foreground"
                          }`}
                        />
                        <span className="text-sm font-medium text-foreground">
                          {team.team}
                        </span>
                      </div>
                      <span className="text-sm font-semibold text-foreground">
                        {team.score}
                      </span>
                    </div>
                    <Progress
                      value={(team.score / 2500) * 100}
                      className="h-2"
                    />
                    <span className="text-xs text-muted-foreground">
                      {team.members} members
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardShell>
  )
}
