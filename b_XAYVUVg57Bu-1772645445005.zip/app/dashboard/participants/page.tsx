"use client"

import { useState } from "react"
import { Search, Mail, Filter } from "lucide-react"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import { StatusBadge } from "@/components/dashboard/status-badge"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { participants } from "@/lib/data"

const teams = ["All", "Phoenix", "Thunder", "Blaze", "Storm"]

export default function ParticipantsPage() {
  const [selectedTeam, setSelectedTeam] = useState("All")
  const [searchQuery, setSearchQuery] = useState("")

  const filtered = participants.filter((p) => {
    const matchesTeam = selectedTeam === "All" || p.team === selectedTeam
    const matchesSearch =
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.email.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesTeam && matchesSearch
  })

  return (
    <DashboardShell
      title="Participants"
      description="View and manage all registered participants"
    >
      <div className="flex flex-col gap-6">
        {/* Summary */}
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {teams.slice(1).map((team) => {
            const count = participants.filter((p) => p.team === team).length
            const avgScore = Math.round(
              participants
                .filter((p) => p.team === team)
                .reduce((a, b) => a + b.score, 0) / count
            )
            return (
              <Card key={team} className="gap-0 py-4">
                <CardContent className="flex flex-col items-center gap-1">
                  <span className="text-lg font-bold text-foreground">{team}</span>
                  <span className="text-2xl font-bold text-primary">{count}</span>
                  <span className="text-xs text-muted-foreground">
                    Avg. score: {avgScore}
                  </span>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Filters */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2 overflow-x-auto">
            <Filter className="size-4 text-muted-foreground shrink-0" />
            {teams.map((team) => (
              <button
                key={team}
                onClick={() => setSelectedTeam(team)}
                className={`shrink-0 rounded-lg px-3 py-1.5 text-sm font-medium transition-colors ${
                  selectedTeam === team
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                }`}
              >
                {team}
              </button>
            ))}
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search participants..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-9 w-full rounded-lg border border-input bg-card pl-9 pr-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring sm:w-64"
            />
          </div>
        </div>

        {/* Table */}
        <Card>
          <CardHeader>
            <CardTitle>All Participants</CardTitle>
            <CardDescription>
              {filtered.length} participant{filtered.length !== 1 ? "s" : ""}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Rank</TableHead>
                  <TableHead>Participant</TableHead>
                  <TableHead className="hidden md:table-cell">
                    Email
                  </TableHead>
                  <TableHead className="hidden sm:table-cell">Team</TableHead>
                  <TableHead className="hidden lg:table-cell">
                    Events
                  </TableHead>
                  <TableHead>Score</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell>
                      <span className="flex size-7 items-center justify-center rounded-md bg-secondary text-xs font-bold text-secondary-foreground">
                        {p.rank}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="size-8">
                          <AvatarFallback className="bg-primary/10 text-primary text-xs">
                            {p.avatar}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-sm font-medium text-foreground">
                          {p.name}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                        <Mail className="size-3.5" />
                        {p.email}
                      </div>
                    </TableCell>
                    <TableCell className="hidden sm:table-cell">
                      <span className="rounded-md bg-secondary px-2 py-1 text-xs font-medium text-secondary-foreground">
                        {p.team}
                      </span>
                    </TableCell>
                    <TableCell className="hidden lg:table-cell">
                      <span className="text-sm text-foreground">{p.events}</span>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm font-semibold text-foreground">
                        {p.score}
                      </span>
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={p.status} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  )
}
