"use client"

import {
  ArrowUp,
  ArrowDown,
  Minus,
  Trophy,
  Medal,
  Star,
} from "lucide-react"
import { DashboardShell } from "@/components/dashboard/dashboard-shell"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { leaderboard, teamScores } from "@/lib/data"
import { cn } from "@/lib/utils"

function TrendIcon({ trend }: { trend: "up" | "down" | "stable" }) {
  if (trend === "up")
    return <ArrowUp className="size-4 text-success" />
  if (trend === "down")
    return <ArrowDown className="size-4 text-destructive" />
  return <Minus className="size-4 text-muted-foreground" />
}

function RankBadge({ rank }: { rank: number }) {
  if (rank === 1)
    return (
      <div className="flex size-9 items-center justify-center rounded-full bg-chart-3/20">
        <Trophy className="size-4 text-chart-3" />
      </div>
    )
  if (rank === 2)
    return (
      <div className="flex size-9 items-center justify-center rounded-full bg-muted">
        <Medal className="size-4 text-muted-foreground" />
      </div>
    )
  if (rank === 3)
    return (
      <div className="flex size-9 items-center justify-center rounded-full bg-chart-5/20">
        <Star className="size-4 text-chart-5" />
      </div>
    )
  return (
    <div className="flex size-9 items-center justify-center rounded-full bg-secondary">
      <span className="text-sm font-bold text-secondary-foreground">
        {rank}
      </span>
    </div>
  )
}

export default function LeaderboardPage() {
  const maxScore = Math.max(...leaderboard.map((e) => e.totalScore))

  return (
    <DashboardShell
      title="Leaderboard"
      description="Competition rankings and standings"
    >
      <div className="flex flex-col gap-6">
        {/* Top 3 Podium */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {leaderboard.slice(0, 3).map((entry, i) => {
            const podiumOrder = [1, 0, 2]
            const person = leaderboard[podiumOrder[i]]
            const position = podiumOrder[i] + 1
            return (
              <Card
                key={person.rank}
                className={cn(
                  "gap-0 py-6",
                  position === 1 && "border-chart-3/40 bg-chart-3/5"
                )}
              >
                <CardContent className="flex flex-col items-center gap-3">
                  <RankBadge rank={position} />
                  <Avatar className="size-14">
                    <AvatarFallback
                      className={cn(
                        "text-lg font-bold",
                        position === 1
                          ? "bg-chart-3/20 text-chart-3"
                          : "bg-primary/10 text-primary"
                      )}
                    >
                      {person.avatar}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col items-center gap-1">
                    <span className="text-base font-semibold text-foreground">
                      {person.name}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {person.team}
                    </span>
                  </div>
                  <span className="text-2xl font-bold text-foreground">
                    {person.totalScore}
                  </span>
                  <div className="flex items-center gap-1">
                    <TrendIcon trend={person.trend} />
                    <span className="text-xs text-muted-foreground">
                      {person.trend === "up"
                        ? `Up from #${person.previousRank}`
                        : person.trend === "down"
                        ? `Down from #${person.previousRank}`
                        : "No change"}
                    </span>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Full Leaderboard */}
        <Card>
          <CardHeader>
            <CardTitle>Full Rankings</CardTitle>
            <CardDescription>
              All {leaderboard.length} competitors ranked by total score
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-16">Rank</TableHead>
                  <TableHead>Competitor</TableHead>
                  <TableHead className="hidden sm:table-cell">Team</TableHead>
                  <TableHead className="hidden md:table-cell">
                    Events
                  </TableHead>
                  <TableHead>Score</TableHead>
                  <TableHead className="hidden sm:table-cell">
                    Progress
                  </TableHead>
                  <TableHead>Trend</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {leaderboard.map((entry) => (
                  <TableRow key={entry.rank}>
                    <TableCell>
                      <RankBadge rank={entry.rank} />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="size-8">
                          <AvatarFallback className="bg-primary/10 text-primary text-xs">
                            {entry.avatar}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-sm font-medium text-foreground">
                          {entry.name}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="hidden sm:table-cell">
                      <span className="rounded-md bg-secondary px-2 py-1 text-xs font-medium text-secondary-foreground">
                        {entry.team}
                      </span>
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      <span className="text-sm text-foreground">
                        {entry.eventsCompleted}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm font-semibold text-foreground">
                        {entry.totalScore}
                      </span>
                    </TableCell>
                    <TableCell className="hidden sm:table-cell">
                      <div className="w-24">
                        <Progress
                          value={(entry.totalScore / maxScore) * 100}
                          className="h-2"
                        />
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5">
                        <TrendIcon trend={entry.trend} />
                        <span className="hidden text-xs text-muted-foreground md:inline-block">
                          {entry.trend === "stable"
                            ? "-"
                            : `#${entry.previousRank}`}
                        </span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Team Leaderboard */}
        <Card>
          <CardHeader>
            <CardTitle>Team Standings</CardTitle>
            <CardDescription>
              Combined team scores
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {teamScores.map((team, i) => (
                <div
                  key={team.team}
                  className={cn(
                    "flex flex-col items-center gap-3 rounded-lg border border-border p-5",
                    i === 0 && "border-chart-3/40 bg-chart-3/5"
                  )}
                >
                  <span className="text-xs font-medium text-muted-foreground">
                    #{i + 1}
                  </span>
                  <span className="text-lg font-bold text-foreground">
                    {team.team}
                  </span>
                  <span className="text-3xl font-bold text-primary">
                    {team.score}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {team.members} members
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  )
}
