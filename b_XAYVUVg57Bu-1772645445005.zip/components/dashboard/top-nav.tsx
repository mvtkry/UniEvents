"use client"

import { Bell, Search, Menu } from "lucide-react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

interface TopNavProps {
  title: string
  description?: string
  onMenuClick: () => void
}

export function TopNav({ title, description, onMenuClick }: TopNavProps) {
  return (
    <header className="flex h-16 shrink-0 items-center justify-between border-b border-border bg-card px-4 lg:px-6">
      <div className="flex items-center gap-3">
        <button
          onClick={onMenuClick}
          className="flex items-center justify-center rounded-lg p-2 text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors lg:hidden"
          aria-label="Toggle menu"
        >
          <Menu className="size-5" />
        </button>
        <div>
          <h1 className="text-lg font-semibold text-foreground">{title}</h1>
          {description && (
            <p className="text-sm text-muted-foreground">{description}</p>
          )}
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button
          className="hidden items-center gap-2 rounded-lg border border-border bg-secondary/50 px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-secondary sm:flex"
          aria-label="Search"
        >
          <Search className="size-4" />
          <span>Search...</span>
        </button>
        <button
          className="relative flex items-center justify-center rounded-lg p-2 text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
          aria-label="Notifications"
        >
          <Bell className="size-5" />
          <Badge className="absolute -top-0.5 -right-0.5 flex size-4 items-center justify-center p-0 text-[10px]">
            3
          </Badge>
        </button>
        <div className="ml-1 flex items-center gap-2">
          <Avatar className="size-8">
            <AvatarFallback className="bg-primary text-primary-foreground text-xs">
              AD
            </AvatarFallback>
          </Avatar>
          <span className="hidden text-sm font-medium text-foreground md:inline-block">
            Admin
          </span>
        </div>
      </div>
    </header>
  )
}
