import { cn } from "@/lib/utils"

type Status =
  | "upcoming"
  | "active"
  | "completed"
  | "registered"
  | "checked-in"
  | "competing"
  | "finished"

const statusConfig: Record<Status, { label: string; className: string }> = {
  upcoming: {
    label: "Upcoming",
    className: "bg-primary/10 text-primary border-primary/20",
  },
  active: {
    label: "Active",
    className: "bg-success/10 text-success border-success/20",
  },
  completed: {
    label: "Completed",
    className: "bg-muted text-muted-foreground border-border",
  },
  registered: {
    label: "Registered",
    className: "bg-secondary text-secondary-foreground border-border",
  },
  "checked-in": {
    label: "Checked In",
    className: "bg-primary/10 text-primary border-primary/20",
  },
  competing: {
    label: "Competing",
    className: "bg-success/10 text-success border-success/20",
  },
  finished: {
    label: "Finished",
    className: "bg-muted text-muted-foreground border-border",
  },
}

interface StatusBadgeProps {
  status: Status
}

export function StatusBadge({ status }: StatusBadgeProps) {
  const config = statusConfig[status]
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-md border px-2 py-0.5 text-xs font-medium",
        config.className
      )}
    >
      {config.label}
    </span>
  )
}
