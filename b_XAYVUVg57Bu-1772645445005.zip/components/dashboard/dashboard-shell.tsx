"use client"

import { useState } from "react"
import { SidebarNav } from "./sidebar-nav"
import { TopNav } from "./top-nav"
import { MobileSidebar } from "./mobile-sidebar"

interface DashboardShellProps {
  children: React.ReactNode
  title: string
  description?: string
}

export function DashboardShell({
  children,
  title,
  description,
}: DashboardShellProps) {
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <div className="hidden lg:block">
        <SidebarNav
          collapsed={collapsed}
          onToggle={() => setCollapsed(!collapsed)}
        />
      </div>
      <MobileSidebar
        open={mobileOpen}
        onClose={() => setMobileOpen(false)}
      />
      <div className="flex flex-1 flex-col overflow-hidden">
        <TopNav
          title={title}
          description={description}
          onMenuClick={() => setMobileOpen(true)}
        />
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">{children}</main>
      </div>
    </div>
  )
}
